/*
* 
*/
package fuzzyAutomaton.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class FuzzyAutomatonNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	* @generated
	*/
	public FuzzyAutomatonNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
