/*
 * 
 */
package fuzzyAutomaton.diagram.providers.assistants;

/**
 * @generated
 */
public class FuzzyAutomatonModelingAssistantProviderOfOutputEditPart
		extends fuzzyAutomaton.diagram.providers.FuzzyAutomatonModelingAssistantProvider {

}
