/*
 * 
 */
package fuzzyAutomaton.diagram.providers.assistants;

/**
 * @generated
 */
public class FuzzyAutomatonModelingAssistantProviderOfInputEditPart
		extends fuzzyAutomaton.diagram.providers.FuzzyAutomatonModelingAssistantProvider {

}
