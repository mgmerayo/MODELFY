/*
 * 
 */
package fuzzyAutomaton.diagram.providers.assistants;

/**
 * @generated
 */
public class FuzzyAutomatonModelingAssistantProviderOfVariableEditPart
		extends fuzzyAutomaton.diagram.providers.FuzzyAutomatonModelingAssistantProvider {

}
