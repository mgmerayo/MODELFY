/*
 * 
 */
package fuzzyAutomaton.diagram.providers.assistants;

/**
 * @generated
 */
public class FuzzyAutomatonModelingAssistantProviderOfVarUpdateEditPart
		extends fuzzyAutomaton.diagram.providers.FuzzyAutomatonModelingAssistantProvider {

}
