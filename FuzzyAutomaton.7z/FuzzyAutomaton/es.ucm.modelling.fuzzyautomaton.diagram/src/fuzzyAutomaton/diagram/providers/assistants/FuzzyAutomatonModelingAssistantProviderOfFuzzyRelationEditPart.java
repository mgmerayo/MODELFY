/*
 * 
 */
package fuzzyAutomaton.diagram.providers.assistants;

/**
 * @generated
 */
public class FuzzyAutomatonModelingAssistantProviderOfFuzzyRelationEditPart
		extends fuzzyAutomaton.diagram.providers.FuzzyAutomatonModelingAssistantProvider {

}
