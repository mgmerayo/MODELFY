/*
 * 
 */
package fuzzyAutomaton.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class FuzzyAutomatonIconProvider extends DefaultElementTypeIconProvider implements IIconProvider {

	/**
	* @generated
	*/
	public FuzzyAutomatonIconProvider() {
		super(fuzzyAutomaton.diagram.providers.FuzzyAutomatonElementTypes.TYPED_INSTANCE);
	}

}
