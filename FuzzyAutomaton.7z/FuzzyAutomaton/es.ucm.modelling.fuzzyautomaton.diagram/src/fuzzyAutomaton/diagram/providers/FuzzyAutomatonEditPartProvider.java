/*
 * 
 */
package fuzzyAutomaton.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class FuzzyAutomatonEditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public FuzzyAutomatonEditPartProvider() {
		super(new fuzzyAutomaton.diagram.edit.parts.FuzzyAutomatonEditPartFactory(),
				fuzzyAutomaton.diagram.part.FuzzyAutomatonVisualIDRegistry.TYPED_INSTANCE,
				fuzzyAutomaton.diagram.edit.parts.FuzzyAutomatonEditPart.MODEL_ID);
	}

}
