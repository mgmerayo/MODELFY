/*
 * 
 */
package fuzzyAutomaton.diagram.edit.helpers;

/**
 * @generated
 */
public class VariableSetEditHelper extends fuzzyAutomaton.diagram.edit.helpers.FuzzyAutomatonBaseEditHelper {
}
