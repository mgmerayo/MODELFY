/*
 * 
 */
package fuzzyAutomaton.diagram.edit.helpers;

/**
 * @generated
 */
public class FuzzyAutomatonEditHelper extends fuzzyAutomaton.diagram.edit.helpers.FuzzyAutomatonBaseEditHelper {
}
