/*
 * 
 */
package fuzzyAutomaton.diagram.edit.helpers;

/**
 * @generated
 */
public class TransitionFeatureEditHelper extends fuzzyAutomaton.diagram.edit.helpers.FuzzyAutomatonBaseEditHelper {
}
