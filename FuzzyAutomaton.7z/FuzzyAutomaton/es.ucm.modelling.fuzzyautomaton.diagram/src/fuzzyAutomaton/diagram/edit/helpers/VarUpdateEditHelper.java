/*
 * 
 */
package fuzzyAutomaton.diagram.edit.helpers;

/**
 * @generated
 */
public class VarUpdateEditHelper extends fuzzyAutomaton.diagram.edit.helpers.FuzzyAutomatonBaseEditHelper {
}
