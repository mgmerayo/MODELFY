/*
 * 
 */
package fuzzyAutomaton.diagram.edit.helpers;

/**
 * @generated
 */
public class VarTransformationEditHelper extends fuzzyAutomaton.diagram.edit.helpers.FuzzyAutomatonBaseEditHelper {
}
