/*
 * 
 */
package fuzzyAutomaton.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	* @generated
	*/
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(
				fuzzyAutomaton.diagram.part.FuzzyAutomatonDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
