/*
 * 
 */
package fuzzyAutomaton.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	* @generated
	*/
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(
				fuzzyAutomaton.diagram.part.FuzzyAutomatonDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
